Dana Alamm - Production Portfolio (GitHub Pages Compatible)

Standalone static frontend. No backend, database, Node.js server,
build step, or environment variables are required to host these files.

All local assets use relative URLs, including JavaScript, CSS, favicon,
portrait, and CV. Works at a domain root or a repository subfolder.

GitHub Pages deployment:
1. Extract the ZIP.
2. Copy the CONTENTS of dist (including .nojekyll) into the root of the
   branch/folder you publish with GitHub Pages, such as a gh-pages branch.
3. In repository Settings > Pages, select that branch and folder.
4. Visit the published repository URL ending in /.
   Do not leave files nested under dist unless you want /dist/ in the URL.

Other static hosts: use dist as the publish/output directory.

For local viewing, from the extracted folder run:
  python3 -m http.server 8000 --directory dist
Then open http://localhost:8000 in a browser. Do not open via file://.

Includes compiled HTML/CSS/JavaScript, portrait, downloadable CV,
and the updated GitHub and LinkedIn links. External links and fonts
require internet access. No credentials or backend files are included.
